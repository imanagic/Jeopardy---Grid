# Fake Jeopardy Part 1

Download the code to get started (Code->Download Zip).

More information here: [https://docs.google.com/document/d/1FkaD_urGqb3G6bgfY1opePvVKpkBbkp7QxOR8cA-pr0/edit?usp=sharing](https://docs.google.com/document/d/1FkaD_urGqb3G6bgfY1opePvVKpkBbkp7QxOR8cA-pr0/edit?usp=sharing)
